package com.example.randomquotegenerator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

data class Quote(
    val text: String,
    val author: String
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    QuoteApp()
                }
            }
        }
    }
}

@Composable
fun QuoteApp() {

    val quotes = listOf(
        Quote(
            "The only way to do great work is to love what you do.",
            "Steve Jobs"
        ),
        Quote(
            "Believe you can and you're halfway there.",
            "Theodore Roosevelt"
        ),
        Quote(
            "It always seems impossible until it's done.",
            "Nelson Mandela"
        ),
        Quote(
            "The future depends on what you do today.",
            "Mahatma Gandhi"
        ),
        Quote(
            "The secret of getting ahead is getting started.",
            "Mark Twain"
        ),
        Quote(
            "Dream big and dare to fail.",
            "Norman Vincent Peale"
        ),
        Quote(
            "Great things are done by a series of small things brought together.",
            "Vincent van Gogh"
        ),
        Quote(
            "Success is not final; failure is not fatal.",
            "Winston Churchill"
        )
    )

    var currentQuote by remember {
        mutableStateOf(quotes[Random.nextInt(quotes.size)])
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),

        horizontalAlignment = Alignment.CenterHorizontally,

        verticalArrangement = Arrangement.Center
    ) {

        Text(
            text = "❝",
            fontSize = 50.sp
        )

        Text(
            text = "Random Quote Generator",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Text(
            text = "A little inspiration, one quote at a time.",
            fontSize = 16.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(
            modifier = Modifier.height(30.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {

            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = "“${currentQuote.text}”",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                Spacer(
                    modifier = Modifier.height(20.dp)
                )

                Text(
                    text = "— ${currentQuote.author}",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(
            modifier = Modifier.height(28.dp)
        )

        Button(
            onClick = {

                var newQuote: Quote

                do {
                    newQuote = quotes[Random.nextInt(quotes.size)]
                } while (
                    newQuote == currentQuote &&
                    quotes.size > 1
                )

                currentQuote = newQuote
            }
        ) {

            Text(
                text = "New Quote"
            )
        }
    }
}