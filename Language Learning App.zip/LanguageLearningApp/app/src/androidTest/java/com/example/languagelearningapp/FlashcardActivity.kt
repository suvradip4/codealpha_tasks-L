package com.example.languagelearningapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.languagelearningapp.ui.theme.LanguageLearningAppTheme

class FlashcardActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            LanguageLearningAppTheme {
                FlashcardScreen()
            }
        }
    }
}

data class Word(
    val english: String,
    val bengali: String,
    val pronunciation: String
)

@androidx.compose.runtime.Composable
fun FlashcardScreen() {

    val words = listOf(
        Word("Apple", "আপেল", "অ্যাপল"),
        Word("Book", "বই", "বুক"),
        Word("Water", "পানি", "ওয়াটার"),
        Word("Beautiful", "সুন্দর", "বিউটিফুল"),
        Word("Friend", "বন্ধু", "ফ্রেন্ড"),
        Word("Happy", "সুখী", "হ্যাপি"),
        Word("Morning", "সকাল", "মর্নিং")
    )

    var currentIndex by remember {
        mutableStateOf(0)
    }

    var showTranslation by remember {
        mutableStateOf(false)
    }

    val currentWord = words[currentIndex]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Spacer(modifier = Modifier.height(25.dp))

        Text(
            text = "🃏 Flashcards",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A237E)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Learn new words",
            fontSize = 16.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(30.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(330.dp)
                .clickable {
                    showTranslation = !showTranslation
                },
            shape = RoundedCornerShape(25.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 8.dp
            )
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(25.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {

                Text(
                    text = "WORD ${currentIndex + 1} / ${words.size}",
                    fontSize = 14.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(25.dp))

                Text(
                    text = currentWord.english,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1A237E)
                )

                Spacer(modifier = Modifier.height(15.dp))

                Text(
                    text = "/${currentWord.pronunciation}/",
                    fontSize = 18.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(25.dp))

                if (showTranslation) {

                    Text(
                        text = currentWord.bengali,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold
                    )

                } else {

                    Text(
                        text = "Tap the card to see translation",
                        fontSize = 15.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(25.dp))

        Button(
            onClick = {
                showTranslation = !showTranslation
            }
        ) {
            Text(
                text = if (showTranslation)
                    "Hide Translation"
                else
                    "Show Translation"
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(15.dp)
        ) {

            Button(
                onClick = {
                    if (currentIndex > 0) {
                        currentIndex--
                    } else {
                        currentIndex = words.lastIndex
                    }

                    showTranslation = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("← Previous")
            }

            Button(
                onClick = {
                    if (currentIndex < words.lastIndex) {
                        currentIndex++
                    } else {
                        currentIndex = 0
                    }

                    showTranslation = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Next →")
            }
        }
    }
}