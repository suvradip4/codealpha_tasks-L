
package com.example.languagelearningapp

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.languagelearningapp.ui.theme.LanguageLearningAppTheme
import java.util.Locale

private val Navy = Color(0xFF263879)
private val Page = Color(0xFFF4F6FC)
private val Lavender = Color(0xFFE7EAF8)
private val Green = Color(0xFF218653)
private val Red = Color(0xFFC43D45)

private data class Word(
    val english: String,
    val bengali: String,
    val pronunciation: String
)

private data class Question(
    val question: String,
    val answer: String,
    val options: List<String>
)

private val words = listOf(
    Word("Apple", "আপেল", "AP-uhl"),
    Word("Book", "বই", "book"),
    Word("Water", "পানি", "WAW-ter"),
    Word("Beautiful", "সুন্দর", "BYOO-ti-ful"),
    Word("Friend", "বন্ধু", "frend"),
    Word("Happy", "সুখী", "HAP-ee"),
    Word("Morning", "সকাল", "MOR-ning"),
    Word("School", "বিদ্যালয়", "skool"),
    Word("Family", "পরিবার", "FAM-uh-lee"),
    Word("Knowledge", "জ্ঞান", "NOL-ij"),
    Word("Thank you", "ধন্যবাদ", "THANK yoo"),
    Word("Good morning", "সুপ্রভাত", "good MOR-ning"),
    Word("Please", "অনুগ্রহ করে", "pleez"),
    Word("House", "বাড়ি", "hows"),
    Word("Love", "ভালোবাসা", "luv")
)

private val questions = listOf(
    Question(
        "What is the Bengali meaning of Apple?",
        "আপেল", listOf("আপেল", "বই", "পানি", "বন্ধু")
    ),
    Question(
        "What is the Bengali meaning of Beautiful?",
        "সুন্দর", listOf("সকাল", "সুন্দর", "বাড়ি", "জ্ঞান")
    ),
    Question(
        "What is the Bengali meaning of Friend?",
        "বন্ধু", listOf("পরিবার", "বিদ্যালয়", "বন্ধু", "আপেল")
    ),
    Question(
        "What is the Bengali meaning of Water?",
        "পানি", listOf("বই", "পানি", "সুখী", "ভালোবাসা")
    ),
    Question(
        "What is the Bengali meaning of Happy?",
        "সুখী", listOf("সুন্দর", "সুখী", "বন্ধু", "সকাল")
    ),
    Question(
        "What is the Bengali meaning of Thank you?",
        "ধন্যবাদ", listOf("ধন্যবাদ", "বাড়ি", "পানি", "বই")
    ),
    Question(
        "What is the Bengali meaning of House?",
        "বাড়ি", listOf("বন্ধু", "সকাল", "বাড়ি", "সুখী")
    ),
    Question(
        "What is the Bengali meaning of Love?",
        "ভালোবাসা", listOf("জ্ঞান", "ভালোবাসা", "বিদ্যালয়", "আপেল")
    )
)

private enum class Screen {
    HOME, LESSON, FLASHCARDS, QUIZ, PROGRESS, GRAMMAR
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            LanguageLearningAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Page
                ) {
                    LanguageLearningApp()
                }
            }
        }
    }
}

@Composable
private fun LanguageLearningApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }

    when (screen) {
        Screen.HOME -> HomeScreen(
            onLesson = { screen = Screen.LESSON },
            onCards = { screen = Screen.FLASHCARDS },
            onQuiz = { screen = Screen.QUIZ },
            onProgress = { screen = Screen.PROGRESS },
            onGrammar = { screen = Screen.GRAMMAR }
        )

        Screen.LESSON -> LessonScreen(
            onBack = { screen = Screen.HOME },
            onCards = { screen = Screen.FLASHCARDS }
        )

        Screen.FLASHCARDS -> FlashcardScreen(
            onBack = { screen = Screen.HOME }
        )

        Screen.QUIZ -> QuizScreen(
            onBack = { screen = Screen.HOME },
            onProgress = { screen = Screen.PROGRESS }
        )

        Screen.PROGRESS -> ProgressScreen(
            onBack = { screen = Screen.HOME }
        )

        Screen.GRAMMAR -> GrammarScreen(
            onBack = { screen = Screen.HOME }
        )
    }
}

@Composable
private fun AppColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Page)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        content = content
    )
}

@Composable
private fun Header(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedButton(onClick = onBack) {
            Text("← Back")
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = title,
            color = Navy,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun HomeScreen(
    onLesson: () -> Unit,
    onCards: () -> Unit,
    onQuiz: () -> Unit,
    onProgress: () -> Unit,
    onGrammar: () -> Unit
) {
    AppColumn {
        Spacer(Modifier.height(20.dp))

        Text(
            "Language Learning",
            fontSize = 29.sp,
            fontWeight = FontWeight.Bold,
            color = Navy,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Learn Every Day 🌎",
            fontSize = 16.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(25.dp))

        Card(
            colors = CardDefaults.cardColors(
                containerColor = Lavender
            ),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(
                    "📚 Daily Lesson",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy
                )
                Spacer(Modifier.height(8.dp))
                Text("Learn five useful English words today.")
                Spacer(Modifier.height(15.dp))
                Button(
                    onClick = onLesson,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Navy
                    )
                ) {
                    Text("Start Lesson")
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            HomeTile("🃏", "Flashcards", Modifier.weight(1f), onCards)
            HomeTile("📝", "Quiz", Modifier.weight(1f), onQuiz)
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            HomeTile("📖", "Grammar", Modifier.weight(1f), onGrammar)
            HomeTile("📊", "My Progress", Modifier.weight(1f), onProgress)
        }

        Spacer(Modifier.height(22.dp))
        Text(
            "Vocabulary • Grammar • Practice",
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun HomeTile(
    emoji: String,
    title: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(125.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.height(7.dp))
            Text(title, fontWeight = FontWeight.Bold, color = Navy)
        }
    }
}

@Composable
private fun LessonScreen(onBack: () -> Unit, onCards: () -> Unit) {
    AppColumn {
        Header("📚 Daily Lesson", onBack)
        Text("Today's vocabulary", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(8.dp))
        Text("Read the words and their Bengali meanings. Then practise with flashcards.")
        Spacer(Modifier.height(15.dp))

        words.take(5).forEachIndexed { index, word ->
            WordCard(index + 1, word)
            Spacer(Modifier.height(10.dp))
        }

        Button(
            onClick = onCards,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Navy)
        ) {
            Text("Practise Flashcards →")
        }
    }
}

@Composable
private fun WordCard(number: Int, word: Word) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$number.", color = Navy, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(word.english, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(word.bengali, fontSize = 18.sp, color = Navy)
                Text("Pronunciation: ${word.pronunciation}", color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun FlashcardScreen(onBack: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    val word = words[index]
    val context = LocalContext.current

    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
        tts = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            tts = null
        }
    }

    AppColumn {
        Header("🃏 Flashcards", onBack)

        Text(
            "Card ${index + 1} of ${words.size}",
            color = Color.Gray,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(18.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .clickable { revealed = !revealed },
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(25.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(word.english, fontSize = 35.sp, fontWeight = FontWeight.Bold, color = Navy)
                Spacer(Modifier.height(12.dp))
                Text("/${word.pronunciation}/", fontSize = 18.sp, color = Color.Gray)
                Spacer(Modifier.height(25.dp))

                if (revealed) {
                    Text(word.bengali, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                } else {
                    Text("Tap the card to reveal the meaning", color = Color.Gray, textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(Modifier.height(15.dp))

        Button(
            onClick = {
                if (ttsReady) {
                    tts?.speak(word.english, TextToSpeech.QUEUE_FLUSH, null, "word")
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Navy)
        ) {
            Text("🔊 Listen to English")
        }

        OutlinedButton(
            onClick = { revealed = !revealed },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (revealed) "Hide Translation" else "Show Translation")
        }

        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = {
                    index = if (index == 0) words.lastIndex else index - 1
                    revealed = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("← Previous")
            }
            Button(
                onClick = {
                    index = (index + 1) % words.size
                    revealed = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Next →")
            }
        }
    }
}

@Composable
private fun QuizScreen(onBack: () -> Unit, onProgress: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("language_learning", Context.MODE_PRIVATE)
    }

    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var finished by remember { mutableStateOf(false) }

    if (finished) {
        QuizResult(
            score = score,
            total = questions.size,
            onRetry = {
                index = 0
                score = 0
                selected = null
                finished = false
            },
            onHome = onBack,
            onProgress = onProgress
        )
        return
    }

    val question = questions[index]

    AppColumn {
        Header("📝 Vocabulary Quiz", onBack)

        Text(
            "Question ${index + 1} of ${questions.size}",
            color = Color.Gray
        )
        Spacer(Modifier.height(10.dp))

        LinearProgressIndicator(
            progress = (index + 1).toFloat() / questions.size,
            modifier = Modifier.fillMaxWidth(),
            color = Navy
        )

        Spacer(Modifier.height(24.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                question.question,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(20.dp)
            )
        }

        Spacer(Modifier.height(15.dp))

        question.options.forEach { option ->
            val isSelected = selected == option
            OutlinedButton(
                onClick = {
                    if (selected == null) {
                        selected = option
                        if (option == question.answer) score++
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (isSelected) Lavender else Color.White,
                    contentColor = Navy
                )
            ) {
                Text(option, fontSize = 18.sp)
            }
        }

        if (selected != null) {
            Spacer(Modifier.height(12.dp))

            Text(
                if (selected == question.answer) "✓ Correct answer!"
                else "Correct answer: ${question.answer}",
                color = if (selected == question.answer) Green else Red,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = {
                    if (index < questions.lastIndex) {
                        index++
                        selected = null
                    } else {
                        val oldBest = prefs.getInt("best_score", 0)
                        prefs.edit()
                            .putInt("last_score", score)
                            .putInt("best_score", maxOf(oldBest, score))
                            .putInt("quizzes_completed", prefs.getInt("quizzes_completed", 0) + 1)
                            .apply()
                        finished = true
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Navy)
            ) {
                Text(if (index < questions.lastIndex) "Next Question →" else "Finish Quiz")
            }
        }
    }
}

@Composable
private fun QuizResult(
    score: Int,
    total: Int,
    onRetry: () -> Unit,
    onHome: () -> Unit,
    onProgress: () -> Unit
) {
    AppColumn {
        Spacer(Modifier.height(70.dp))
        Text("🎉", fontSize = 60.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(15.dp))
        Text(
            "Quiz Complete!",
            fontSize = 29.sp,
            fontWeight = FontWeight.Bold,
            color = Navy,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Text(
            "$score / $total",
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Text(
            "${score * 100 / total}% correct",
            color = Color.Gray,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(30.dp))

        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) {
            Text("Try Again")
        }
        OutlinedButton(onClick = onProgress, modifier = Modifier.fillMaxWidth()) {
            Text("View Progress")
        }
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth()) {
            Text("Back to Home")
        }
    }
}

@Composable
private fun ProgressScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("language_learning", Context.MODE_PRIVATE)
    }

    var refresh by remember { mutableIntStateOf(0) }
    val lastScore = remember(refresh) { prefs.getInt("last_score", 0) }
    val bestScore = remember(refresh) { prefs.getInt("best_score", 0) }
    val quizCount = remember(refresh) { prefs.getInt("quizzes_completed", 0) }

    var showResetDialog by remember { mutableStateOf(false) }

    AppColumn {
        Header("📊 My Progress", onBack)

        Text("Keep practising every day!", color = Color.Gray)
        Spacer(Modifier.height(20.dp))

        ProgressCard("Vocabulary words", "${words.size}", "📚")
        Spacer(Modifier.height(12.dp))
        ProgressCard("Last quiz score", "$lastScore / ${questions.size}", "📝")
        Spacer(Modifier.height(12.dp))
        ProgressCard("Best quiz score", "$bestScore / ${questions.size}", "🏆")
        Spacer(Modifier.height(12.dp))
        ProgressCard("Quizzes completed", "$quizCount", "🎯")

        Spacer(Modifier.height(22.dp))
        Text("Best quiz result", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))

        LinearProgressIndicator(
            progress = bestScore.toFloat() / questions.size,
            modifier = Modifier.fillMaxWidth(),
            color = Green
        )
        Text("${bestScore * 100 / questions.size}% best score", color = Color.Gray)

        Spacer(Modifier.height(25.dp))

        OutlinedButton(
            onClick = { showResetDialog = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reset Progress")
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset progress?") },
            text = { Text("Your saved quiz scores and quiz count will be erased.") },
            confirmButton = {
                TextButton(onClick = {
                    prefs.edit().clear().apply()
                    refresh++
                    showResetDialog = false
                }) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ProgressCard(title: String, value: String, emoji: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 32.sp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, color = Color.Gray, fontSize = 14.sp)
                Text(value, color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun GrammarScreen(onBack: () -> Unit) {
    AppColumn {
        Header("📖 English Grammar", onBack)

        Text("Simple grammar lessons", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(15.dp))

        GrammarCard(
            "Present Simple",
            "Use it for habits, routines and facts.",
            "I study English every day.",
            "আমি প্রতিদিন ইংরেজি পড়ি।"
        )
        Spacer(Modifier.height(12.dp))

        GrammarCard(
            "Past Simple",
            "Use it for actions that happened in the past.",
            "I studied English yesterday.",
            "আমি গতকাল ইংরেজি পড়েছিলাম।"
        )
        Spacer(Modifier.height(12.dp))

        GrammarCard(
            "Future Simple",
            "Use it for actions that will happen in the future.",
            "I will study English tomorrow.",
            "আমি আগামীকাল ইংরেজি পড়ব।"
        )
        Spacer(Modifier.height(12.dp))

        GrammarCard(
            "Present Continuous",
            "Use it for an action happening now.",
            "I am learning English.",
            "আমি ইংরেজি শিখছি।"
        )
    }
}

@Composable
private fun GrammarCard(
    title: String,
    explanation: String,
    example: String,
    bengali: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
            Spacer(Modifier.height(8.dp))
            Text(explanation, color = Color.DarkGray)
            Spacer(Modifier.height(10.dp))
            Text("Example", fontWeight = FontWeight.Bold)
            Text(example, fontSize = 17.sp)
            Text(bengali, fontSize = 16.sp, color = Green)
        }
    }
}
